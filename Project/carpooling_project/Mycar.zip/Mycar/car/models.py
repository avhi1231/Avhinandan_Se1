from django.db import models
import uuid

# Create your models here.

class CarListing(models.Model):
    TRANSMISSION_CHOICES = [
        ('automatic', 'Automatic'),
        ('manual', 'Manual'),
    ]

    FUEL_CHOICES = [
        ('CNG&Hybrids', 'CNG & Hybrids'),
        ('Diesel', 'Diesel'),
        ('Electric', 'Electric'),
        ('LPG', 'LPG'),
        ('Petrol', 'Petrol'),
    ]

    OWNER_CHOICES = [
        ('1st', '1st'),
        ('2nd', '2nd'),
        ('3rd', '3rd'),
        ('3rd+', '3rd+'),
    ]

    seller_name = models.CharField(max_length=100)
    brand = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    fuel = models.CharField(max_length=20, choices=FUEL_CHOICES)
    transmission = models.CharField(max_length=10, choices=TRANSMISSION_CHOICES)
    km_driven = models.PositiveIntegerField()
    owners = models.CharField(max_length=5, choices=OWNER_CHOICES)
    phone = models.CharField(max_length=15,default="0000000000")    
    year = models.PositiveIntegerField()
    vin = models.CharField(max_length=50, unique=True)
    ad_title = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    car_image1 = models.ImageField(upload_to='car_images/', blank=True, null=True)
    car_image2 = models.ImageField(upload_to='car_images/', blank=True, null=True)
    car_image3 = models.ImageField(upload_to='car_images/', blank=True, null=True)
    car_image4 = models.ImageField(upload_to='car_images/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.brand} {self.model} - {self.seller_name}"
    
class BuyCarEnquire(models.Model):
    car = models.ForeignKey('CarListing', on_delete=models.CASCADE)  # Link to CarListing
    name = models.CharField(max_length=100)  # Customer Name
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    message = models.TextField(blank=True, null=True)
    enquired_at = models.DateTimeField(auto_now_add=True)

    # Store car details for history purposes
    seller_name = models.CharField(max_length=100, editable=False)
    brand = models.CharField(max_length=100, editable=False)
    model = models.CharField(max_length=100, editable=False)
    fuel = models.CharField(max_length=20, editable=False)
    transmission = models.CharField(max_length=10, editable=False)
    km_driven = models.PositiveIntegerField(editable=False)
    owners = models.CharField(max_length=5, editable=False)
    year = models.PositiveIntegerField(editable=False)
    vin = models.CharField(max_length=50, editable=False)
    ad_title = models.CharField(max_length=255, editable=False)
    description = models.TextField(editable=False)
    price = models.DecimalField(max_digits=10, decimal_places=2, editable=False)
    car_image1 = models.ImageField(upload_to='enquiry_images/', blank=True, null=True, editable=False)
    car_image2 = models.ImageField(upload_to='enquiry_images/', blank=True, null=True, editable=False)
    car_image3 = models.ImageField(upload_to='enquiry_images/', blank=True, null=True, editable=False)
    car_image4 = models.ImageField(upload_to='enquiry_images/', blank=True, null=True, editable=False)
 

    def save(self, *args, **kwargs):
        """Override save method to copy car details."""
        if self.car:
            self.seller_name = self.car.seller_name
            self.brand = self.car.brand
            self.model = self.car.model
            self.fuel = self.car.fuel
            self.transmission = self.car.transmission
            self.km_driven = self.car.km_driven
            self.owners = self.car.owners
            self.year = self.car.year
            self.vin = self.car.vin
            self.ad_title = self.car.ad_title
            self.description = self.car.description
            self.price = self.car.price
            self.car_image1 = self.car.car_image1
            self.car_image2 = self.car.car_image2
            self.car_image3 = self.car.car_image3
            self.car_image4 = self.car.car_image4

        super(BuyCarEnquire, self).save(*args, **kwargs)

    def __str__(self):
        return f"Enquiry by {self.id} -{self.name} for {self.brand} {self.model} ({self.year})"




class Contactus(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    message = models.TextField(blank=True, null=True)
    