from django.contrib import admin
from .models import CarListing,BuyCarEnquire,Contactus

# Register your models here.s

@admin.register(CarListing)
class CarListingAdmin(admin.ModelAdmin):
    list_display = ('seller_name', 'brand', 'model', 'year', 'price', 'created_at')
    search_fields = ('seller_name', 'brand', 'model', 'vin')
    list_filter = ('brand', 'fuel', 'transmission', 'owners', 'year')
    ordering = ('-created_at',)

@admin.register(BuyCarEnquire)
class BuyCarEnquireAdmin(admin.ModelAdmin):
    list_display = ('id','name', 'email', 'phone', 'message')
    # search_fields = ('seller_name', 'brand', 'model', 'vin')
    # list_filter = ('brand', 'fuel', 'transmission', 'owners', 'year')
    # ordering = ('-created_at',)

@admin.register(Contactus)
class ContactusAdmin(admin.ModelAdmin):
    list_display = ('id','name', 'email', 'phone','subject', 'message')