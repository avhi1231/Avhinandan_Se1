from django.shortcuts import render,redirect
from .models import CarListing,BuyCarEnquire,Contactus
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required

from math import ceil
# Create your views here.
def index(request):
    allCars = []
    brandcar= CarListing.objects.values('brand', 'id')
    brands = {item['brand'] for item in brandcar}
    for brand in brands:
        cars = CarListing.objects.filter(brand=brand)
        n = len(cars)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allCars.append([cars, range(1, nSlides), nSlides])
      
        params = {'allCars':allCars}
    return render (request,'car/index.html',params)

@login_required
def sale_your_car(request):
    if request.method == "POST":
        seller_name = request.POST.get('seller_name')
        phone = request.POST.get('phone')
        brand = request.POST.get('brand')
        model = request.POST.get('car_model')
        fuel = request.POST.get('fuel')
        transmission = request.POST.get('transmission')
        km_driven = request.POST.get('km')
        owners = request.POST.get('Owners')
        year = request.POST.get('year')
        vin = request.POST.get('vin')
        ad_title = request.POST.get('title')
        description = request.POST.get('cardescription')
        price = request.POST.get('price')
        car_image1 = request.FILES.get('carimg1')
        car_image2 = request.FILES.get('carimg2')
        car_image3 = request.FILES.get('carimg3')
        car_image4 = request.FILES.get('carimg4')

        CarListing.objects.create(
            seller_name=seller_name,
            phone=phone,
            brand=brand,
            model=model,
            fuel=fuel,
            transmission=transmission,
            km_driven=km_driven,
            owners=owners,
            year=year,
            vin=vin,
            ad_title=ad_title,
            description=description,
            price=price,
            car_image1=car_image1,
            car_image2=car_image2,
            car_image3=car_image3,
            car_image4=car_image4
        )
        return redirect('car_sale')  # Redirect to a success page
    return render(request, 'car/sale_your_car.html')

@login_required
def car_sale(request):
    allCars = []
    brandcar= CarListing.objects.values('brand', 'id')
    brands = {item['brand'] for item in brandcar}
    for brand in brands:
        cars = CarListing.objects.filter(brand=brand)
        n = len(cars)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allCars.append([cars, range(1, nSlides), nSlides])
        
        params = {'allCars':allCars}


    # car_list=CarListing.objects.all()
    # n = len(car_list)
    # nSlides = n//4 + ceil((n/4)-(n//4))
    # allCars=[[car_list, range(1, len(car_list)), nSlides],[car_list, range(1, len(car_list)), nSlides]]
    # params={'allCars':allCars }
    return render (request,'car/car_sale.html',params)
def about(request):
    return render (request,'car/about.html')

@login_required
def contactus(request):
    if request.method == "POST":
        c_name = request.POST.get('c_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        msg = request.POST.get('msg')
        subject = request.POST.get('subject')

        Contactus.objects.create(
            name=c_name,
            email=email,
            phone=phone,
            message=msg,
            subject=subject,
        )
        return redirect('contactus')  # Redirect to a success page

    else:
        return render (request,'car/contactus.html')


def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'car/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'car/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('index')




@login_required
def viewscar(request,id):
    if request.method == "POST":
        findcar=CarListing.objects.get(id=id)
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        msg = request.POST.get('msg')

        enquiry = BuyCarEnquire.objects.create(
            car=findcar,
            name=name,
            email=email,
            phone=phone,
            message=msg
        )
     
        return render(request,'car/viewscar.html',{'findcar':findcar ,'enquiry_id':enquiry.id})

        
    else:
        pass
    findcar=CarListing.objects.get(id=id)
    return render(request,'car/viewscar.html',{'findcar':findcar})