from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add_course/', views.add_course, name='add_course'),
    path('courses/', views.list_courses, name='list_courses'),
    path('add_student/', views.add_student, name='add_student'),
    path('students/', views.list_students, name='list_students'),
]
