from django.shortcuts import render, redirect
from .forms import CourseForm, StudentForm
from .models import Course, Student

def home(request):
    return render(request, 'management/home.html')

def add_course(request):
    form = CourseForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('list_courses')
    return render(request, 'management/add_course.html', {'form': form})

def list_courses(request):
    courses = Course.objects.all()
    return render(request, 'management/list_courses.html', {'courses': courses})

def add_student(request):
    form = StudentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('list_students')
    return render(request, 'management/add_student.html', {'form': form})

def list_students(request):
    students = Student.objects.select_related('course').all()
    return render(request, 'management/list_students.html', {'students': students})
