from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

@login_required
def custom_redirect(request):
    return redirect('/dashboard/')  # Change this to your desired 
